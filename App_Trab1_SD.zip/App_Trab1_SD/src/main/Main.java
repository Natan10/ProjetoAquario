package main;

import gerenciador.Gerenciador;

public class Main {

	public static void main(String[] args) {
		Gerenciador gere = new Gerenciador();
		System.out.print("Alou Mundo!");
		
		gere.estabelecerConexao("localhost", 1234);
		
		gere.enviarRequisicao(1, "ababa");
		
		gere.encerrarConexao();
	}
}
