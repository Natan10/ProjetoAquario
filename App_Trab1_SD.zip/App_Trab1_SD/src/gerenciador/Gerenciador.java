package gerenciador;

import java.net.*;
import java.io.*;
import protobuff.AquarioOuterClass.*;

public class Gerenciador {
	private Socket s;
	private DataOutputStream saida;
	private DataInputStream entrada;
	
	public Gerenciador() {
		s = null;
		saida = null;
		entrada = null;
	}
	
	public void estabelecerConexao(String serverIP, int serverPort) {
		try {
			s = new Socket(serverIP, serverPort);
			saida = new DataOutputStream(s.getOutputStream());
			entrada = new DataInputStream(s.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void encerrarConexao() {
		try {
			s.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void enviarRequisicao(int tipo, String infAdicional) {
		try {
			Request.Builder req = Request.newBuilder();
			req.setTipo(tipo);
			req.setInfAdicional(infAdicional);
			
			req.build().writeTo(saida);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public Response receberResposta() {
		try {
			return Response.parseFrom(entrada);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return null;
	}
}
